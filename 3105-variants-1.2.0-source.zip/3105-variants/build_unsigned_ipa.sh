#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD_DIR="$ROOT_DIR/build/Release-iphoneos"
DIST_DIR="$ROOT_DIR/dist"
APP_PATH="$BUILD_DIR/3105.app"

rm -rf "$ROOT_DIR/build" "$DIST_DIR"
mkdir -p "$DIST_DIR"

xcodebuild \
  -project "$ROOT_DIR/ThreeOneOSFive.xcodeproj" \
  -scheme 3105 \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$ROOT_DIR/build/DerivedData" \
  CONFIGURATION_BUILD_DIR="$BUILD_DIR" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM=""

if [ ! -d "$APP_PATH" ]; then
  echo "Build completed but $APP_PATH was not produced." >&2
  exit 1
fi

mkdir -p "$DIST_DIR/Payload"
cp -R "$APP_PATH" "$DIST_DIR/Payload/3105.app"
(
  cd "$DIST_DIR"
  /usr/bin/zip -qry "3105-variants-unsigned.ipa" Payload
)
rm -rf "$DIST_DIR/Payload"

printf 'Unsigned IPA: %s\n' "$DIST_DIR/3105-variants-unsigned.ipa"
/usr/bin/shasum -a 256 "$DIST_DIR/3105-variants-unsigned.ipa"
