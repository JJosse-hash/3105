#!/usr/bin/env python3
from __future__ import annotations

import plistlib
import re
from pathlib import Path

ROOT = Path('/home/ubuntu/3105-variants')


def strip_swift_comments_and_strings(text: str) -> str:
    out = []
    i = 0
    state = 'code'
    block_depth = 0
    while i < len(text):
        if state == 'code':
            if text.startswith('//', i):
                state = 'line_comment'
                out.append('  ')
                i += 2
            elif text.startswith('/*', i):
                state = 'block_comment'
                block_depth = 1
                out.append('  ')
                i += 2
            elif text[i] == '"':
                state = 'string'
                out.append('"')
                i += 1
            else:
                out.append(text[i])
                i += 1
        elif state == 'line_comment':
            if text[i] == '\n':
                state = 'code'
                out.append('\n')
            else:
                out.append(' ')
            i += 1
        elif state == 'block_comment':
            if text.startswith('/*', i):
                block_depth += 1
                out.append('  ')
                i += 2
            elif text.startswith('*/', i):
                block_depth -= 1
                out.append('  ')
                i += 2
                if block_depth == 0:
                    state = 'code'
            else:
                out.append('\n' if text[i] == '\n' else ' ')
                i += 1
        else:
            if text[i] == '\\' and i + 1 < len(text):
                out.append('  ')
                i += 2
            elif text[i] == '"':
                out.append('"')
                i += 1
                state = 'code'
            else:
                out.append(' ')
                i += 1
    return ''.join(out)


def check_delimiters(path: Path) -> None:
    text = strip_swift_comments_and_strings(path.read_text())
    pairs = {')': '(', ']': '[', '}': '{'}
    stack: list[tuple[str, int]] = []
    for line_no, line in enumerate(text.splitlines(), 1):
        for char in line:
            if char in '([{':
                stack.append((char, line_no))
            elif char in pairs:
                if not stack or stack[-1][0] != pairs[char]:
                    raise SystemExit(f'FAIL: delimiter mismatch in {path}:{line_no}')
                stack.pop()
    if stack:
        raise SystemExit(f'FAIL: unclosed delimiter in {path}:{stack[-1][1]}')
    print(f'PASS: delimiters {path.name}')


def check_strings(path: Path) -> None:
    keys = re.findall(r'^\s*"([^"\\]+)"\s*=', path.read_text(), flags=re.MULTILINE)
    duplicates = sorted({key for key in keys if keys.count(key) > 1})
    if duplicates:
        raise SystemExit(f'FAIL: duplicate localization keys in {path}: {duplicates}')
    print(f'PASS: localization keys {path.parent.name}')


for swift in [
    ROOT / 'ThreeOneOSFive/helpers/PatchPackageCodec.swift',
    ROOT / 'ThreeOneOSFive/helpers/PatchProjectLibrary.swift',
    ROOT / 'ThreeOneOSFive/helpers/PatchProjectModels.swift',
    ROOT / 'ThreeOneOSFive/helpers/PatchProjectStore.swift',
    ROOT / 'ThreeOneOSFive/views/PatchProjectsView.swift',
]:
    check_delimiters(swift)

for strings in sorted((ROOT / 'ThreeOneOSFive').glob('*.lproj/Localizable.strings')):
    check_strings(strings)

plistlib.loads((ROOT / 'ThreeOneOSFive/Info.plist').read_bytes())
print('PASS: Info.plist parses')
